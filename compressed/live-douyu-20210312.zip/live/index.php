<?php
    require_once('config/config.php');
    if(getServerSchema()){
        //跳转到http协议
        Header("HTTP/1.1 301 Moved Permanently");
        header('Location: http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
    }
    
    function getServerSchema(){
        if ( (!empty($_SERVER['REQUEST_SCHEME']) && $_SERVER['REQUEST_SCHEME'] == 'https') || (! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (! empty($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443') ) {
           //return 'https';
           return true;
        }
        //return 'http';
        return false;
    }
?>
<!doctype html>
<html lang="zh-CN">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
	    <meta http-equiv="Cache-Control" content="no-transform" />
	    <meta http-equiv="Cache-Control" content="no-siteapp" />
	    <meta name="renderer" content="webkit"/>
	    <meta name="force-rendering" content="webkit"/>
	    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1"/>
	    <meta name="keywords" content="直播,视频直播,网络直播" />
        <meta name="description" content="聚合全网直播资源" />
	    <title><?php echo $siteName; ?></title>
	    <link rel='dns-prefetch' href='//live.urapi.xin' />
        <link rel='dns-prefetch' href='//urhost.cn' />
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/Message/css/message.css">
        <script>
        var _hmt = _hmt || [];
        (function() {
          var hm = document.createElement("script");
          hm.src = "https://hm.baidu.com/hm.js?c9de5f629f09295bd6ac6dfc8dcf2f44";
          var s = document.getElementsByTagName("script")[0]; 
          s.parentNode.insertBefore(hm, s);
        })();
        </script>
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-7G19F60K9M"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
        
          gtag('config', 'G-7G19F60K9M');
        </script>

    </head>
    <body style="background-color: #f8f9fa">
        <div class="container-fluid" style="height:100%;">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
              <a class="navbar-brand" href="https://www.urweibo.com/">URWeibo</a>
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
            
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                  <li class="nav-item active">
                    <a class="nav-link" target="_blank" href="https://www.urweibo.com">首页 <span class="sr-only">(current)</span></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="http://www.urweibo.com/live">纯净直播</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" target="_blank" href="https://urhost.cn" tabindex="-1" aria-disabled="true">下载当前源码</a>
                  </li>
                </ul>
                
                <form class="form-inline my-2 my-lg-0" onsubmit="javascript:return false;">
                  <button class="btn btn-default" style="display:none">历史记录</button>
                  <select class="custom-select" id="inputGroupSelect01">
                    <option <?php if($defaultPlatform == 'douyu'){echo 'selected';} ?> value="douyu">斗鱼</option>
                    <option <?php if($defaultPlatform == 'huya'){echo 'selected';} ?> value="huya">虎牙</option>
                    <option <?php if($defaultPlatform == 'bilibili'){echo 'selected';} ?> value="bilibili">哔哩哔哩</option>
                    <option <?php if($defaultPlatform == 'egame'){echo 'selected';} ?> value="egame">企鹅电竞</option>
                  </select>
                  <input class="form-control mr-sm-2" type="search" value="<?php echo $defaultRoom;?>" placeholder="房间号" id="roomId" aria-label="Search">
                  <button class="btn btn-outline-success my-2 my-sm-0" type="button" id="loadBtn">加载</button>
                </form>
              </div>
            </nav>
            <div class="row">
                <div id="dplayer" style="margin:0 auto;"></div>    
            </div>
            <?php 
                //请勿修改下面的内容，改了程序无法使用
            ?>
            
            <div class="bg-light text-center copyright">
                版权声明：所有直播内容均采集于网络，如有问题请联系<a href="https://xiucai.in" target="_blank">@Xiucai</a>
            </div>
            <?php 
                //请勿修改上面的内容，改了程序无法使用
            ?>
            
        </div>
        
        <script src="assets/bootstrap/js/jquery.min.js"></script>
        <script src="assets/bootstrap/js/base64.js"></script>
        <script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>
        
        <script src="assets/player/hls.min.js"></script>
        <script src="assets/player/flv.min.js"></script>
        <script src="assets/player/DPlayer.min.js"></script>
        
        <script src="assets/Message/js/message.min.js"></script>
        <script src="assets/urweibo.min.js"></script>
        
        <?php 
            if($checkUpdate){
                echo '<script>$.getJSON("//update.urapi.xin/live/c.php?v='.$version.'&c="+Base64.encode($(".copyright").html().replace(/^\s+|\s+$/g,""))+"&o="+Base64.encode(location.href),function(result){if(result.code == 0){Qmsg.warning(result.msg,{showClose:true,autoClose:false,onClose:function(){}})}});</script>';
            }
        ?>

    </body>
    
</html>