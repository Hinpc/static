<?php

$siteName = '纯净直播 - 聚合全网直播资源';

$version = 20210312;

//douyu huya bilibili egame
$defaultPlatform = 'douyu';

//默认加载的直播间ID
$defaultRoom = '100';

//true 自动检测更新；false 不检测更新
$checkUpdate = true;

//true 启用历史记录；false 不启用历史记录
$showHistory = false;

